/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyecto_tap;


public class Proyecto_TAP {

    public static void main(String[] args) {
        new IniciarsesionFrame().setVisible(true);
    }
}
