
package com.mycompany.proyecto_tap.clases;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class Cita implements Serializable {
    
    //private String especialista;
    private int precio=500;
    private Persona cliente;
    private Persona doctor;
    //private String fechaa;
    private String fecha;
    private boolean citaPagada=false;
    private int avancePago;
    
    

    public Cita() {
    }

    public Cita(int precio,Persona doctor,Persona cliente, String fecha, int avancePago) {
        this.precio=precio;
        this.doctor = doctor;
        this.cliente=cliente;
        this.fecha=fecha;
        this.avancePago=avancePago;
        citaPagada=false;
        
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public Persona getCliente() {
        return cliente;
    }

    public void setCliente(Persona cliente) {
        this.cliente = cliente;
    }

    public Persona getDoctor() {
        return doctor;
    }

    public void setDoctor(Persona doctor) {
        this.doctor = doctor;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public boolean isCitaPagada() {
        return citaPagada;
    }

    public void setCitaPagada(boolean citaPagada) {
        this.citaPagada = citaPagada;
    }

    public int getAvancePago() {
        return avancePago;
    }

    public void setAvancePago(int avancePago) {
        this.avancePago = avancePago;
    }

    

    
}