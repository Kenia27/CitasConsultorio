/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_tap;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author kenia
 */
public class Xtream {
   public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int T = in.nextInt(); // Leer el número de casos de prueba

        for (int t = 0; t < T; t++) {
            int N = in.nextInt(); // Leer el valor de N para cada caso de prueba
            
            if (N > 10_000) {
                // No es posible construir una secuencia duplicada para N > 10^6
                System.out.println(-1);
                continue;
            }

            int[] S = new int[2 * N]; // Crear la secuencia de longitud 2N
            for (int i = 1; i <= N; i++) {
                S[i - 1] = i; // Primera aparición en posición i
                S[2 * i - 1] = i; // Segunda aparición en posición 2i
            }

            // Imprimir la secuencia duplicada
            StringBuilder result = new StringBuilder();
            for (int num : S) {
                result.append(num).append(" ");
            }
            System.out.println(result.toString().trim()); // Quitar el espacio final
        }

        in.close();
    }

}

