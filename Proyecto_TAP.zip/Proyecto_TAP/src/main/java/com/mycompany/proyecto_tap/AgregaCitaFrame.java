/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.proyecto_tap;

import javax.swing.*;
import java.awt.*;
import java.time.*;
import java.util.ArrayList;
import java.io.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.mycompany.proyecto_tap.clases.Cita;
import com.mycompany.proyecto_tap.clases.Persona;
import com.toedter.calendar.JCalendar;

/**
 *
 * @author whois
 */
public class AgregaCitaFrame extends javax.swing.JFrame {
    
    private JComboBox<String> comboBoxHora;
    private JCalendar calendar;
    private ArrayList<Persona> listPersonas=new ArrayList<>();
    private ArrayList<Cita> citasReservadasC=new ArrayList<>();
    private ArrayList<Cita> citasReservadasD=new ArrayList<>();
    private Persona cliente=new Persona();
    private Persona doctor=new Persona();
    int indexD,indexC;
    
    public AgregaCitaFrame() {
        initComponents();
        agrega();
        
    }
    public AgregaCitaFrame(Persona doctor,int indexD, Persona cliente,int indexC, ArrayList<Persona> listPersonas) {
        initComponents();
        this.doctor=doctor;
        this.indexD=indexD;
        this.cliente=cliente;
        this.indexD=indexD;
        this.listPersonas=listPersonas;
        agrega();
        //cargarCitasReservadas();
        JFrame IniciarsesionFrame = new JFrame();

        // Establece el color de fondo
        //Color color = new Color(255, 211, 211);
        //IniciarsesionFrame.getContentPane().setBackground(color);

        // Actualiza el JFrame para que se muestren los cambios
        IniciarsesionFrame.repaint();
        getContentPane().setBackground(new Color(180, 205, 230));
    }
    private void agrega() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Disponibilidad de Citas");
        setLayout(new BorderLayout());

        // Inicializar lista de citas reservadas
        citasReservadasC=cliente.getCitasReservadas();

        // Calendario para seleccionar la fecha
        calendar = new JCalendar();
        add(calendar, BorderLayout.CENTER);
        calendar.setBackground(new Color(180, 205, 230));

        // ComboBox para seleccionar la hora
        comboBoxHora = new JComboBox<>();
        for (int hora = 9; hora <= 17; hora++) {
            if(hora==9)
                comboBoxHora.addItem("0"+hora + ":00");
            else
                comboBoxHora.addItem(hora + ":00");
        }
        add(comboBoxHora, BorderLayout.SOUTH);
         comboBoxHora.setBackground(new Color(180, 205, 230));
        // Botón para reservar cita
        JButton btnReservar = new JButton("Reservar Cita");
        btnReservar.addActionListener(e -> reservarCita());
        add(btnReservar, BorderLayout.NORTH);
         btnReservar.setBackground(new Color(180, 205, 230));
        pack();
        setLocationRelativeTo(null); // Centrar la ventana en la pantalla
        setVisible(true);
    }

   

    private void reservarCita() {
        LocalDate fechaSeleccionada = calendar.getDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        String horaSeleccionada = (String) comboBoxHora.getSelectedItem();

        // Combinar fecha y hora seleccionadas
        LocalDateTime citaSeleccionada = LocalDateTime.of(fechaSeleccionada, LocalTime.parse(horaSeleccionada));
        
        LocalDate fechaActual = LocalDate.now();
        LocalDate fechaLimite = fechaActual.plusDays(30);
        if (fechaSeleccionada.isAfter(fechaLimite)) {
            JOptionPane.showMessageDialog(this, "Solo se pueden reservar citas dentro de los próximos 30 días.");
            return;
        }
        if(fechaSeleccionada.isBefore(LocalDate.now())){
        JOptionPane.showMessageDialog(this, "Esta fecha ya pasó. Por favor, selecciona otra fecha");
            return;
        }
        // Comprobar si la cita ya está reservada
        if (citasReservadasC.contains(citaSeleccionada)) {
            JOptionPane.showMessageDialog(this, "Esta cita ya está reservada. Por favor, selecciona otra fecha u hora.");
            return;
        }
        
        if (fechaSeleccionada.getDayOfWeek() == DayOfWeek.SUNDAY) {
            JOptionPane.showMessageDialog(this, "No se pueden reservar citas en domingo.");
            return;
        }

        // Si la cita no está reservada, agregarla a la lista de citas reservadas
        Cita cita1=new Cita();
        cita1.setDoctor(doctor);
        cita1.setCliente(cliente);
        cita1.setPrecio(doctor.getCostoConsulta());
        cita1.setFecha(""+citaSeleccionada);
        citasReservadasC.add(cita1);
        citasReservadasD.add(cita1);
        
        listPersonas.set(indexD, doctor);
        listPersonas.set(indexC, cliente);
        
        //guardarCitasReservadas(); // Guardar las citas reservadas
        JOptionPane.showMessageDialog(this, "Cita reservada con éxito para el " + citaSeleccionada);
        dispose();
        //cambiar();
    }
    
    public ArrayList<String> cambiar(){
        ArrayList<String> citasString = new ArrayList<>();
        for (int i=0;i<citasReservadasC.size();i++)
            citasString.add(""+citasReservadasC.get(i));
        System.out.println(citasString.toString());
        return citasString;
    }

    public ArrayList<Cita> getCitasReservadas() {
        return citasReservadasC;
    }

    public void setCitasReservadas(ArrayList<Cita> citasReservadas) {
        this.citasReservadasC = citasReservadas;
    }

    public ArrayList<Persona> getListPersonas() {
        return listPersonas;
    }
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AgregaCitaFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AgregaCitaFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AgregaCitaFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AgregaCitaFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AgregaCitaFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
